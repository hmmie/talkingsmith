import random
import winsound
import os
fileat = os.path.dirname(os.path.abspath(__file__)) + str("\g")
def smithanswer():
    randomvar = random.randint(1, 5)
    if randomvar == 1:
        print("Smith - heeeeegh")
        winsound.PlaySound(fileat + "mithhohoho", winsound.SND_FILENAME)
        smithstart()
    if randomvar == 2:
        print("Smith - yes")
        winsound.PlaySound(fileat + "mithyes", winsound.SND_FILENAME)
        smithstart()
    if randomvar == 3:
        print("Smith - no")
        winsound.PlaySound(fileat + "mithno", winsound.SND_FILENAME)
        smithstart()
    if randomvar == 4:
        print("Smith - eugh")
        winsound.PlaySound(fileat + "mithaugg", winsound.SND_FILENAME)
        smithstart()
    if randomvar == 5:
        print("Smith ate the line!")
        winsound.PlaySound(fileat + "mithcutline", winsound.SND_FILENAME)
        askstart()
def smithstart():
    input("Ask smith a question: ")
    smithanswer()
def askstart():
    if input("What do you want to do (phone or close) ") == "phone":
        winsound.PlaySound(fileat + "mithstart", winsound.SND_FILENAME)
        print("Smith")
        smithstart()
    else:
        quit()
askstart()
